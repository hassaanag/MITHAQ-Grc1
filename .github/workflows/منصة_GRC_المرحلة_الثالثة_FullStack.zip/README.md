# منصة GRC المؤسسية — المرحلة الثالثة

هذه المرحلة تنقل المشروع من Prototype يعمل داخل المتصفح فقط إلى **Full‑Stack Starter**:

- Backend API باستخدام FastAPI
- قاعدة بيانات SQLAlchemy
- SQLite للتشغيل السريع محليًا
- دعم PostgreSQL عبر Docker Compose
- تسجيل دخول JWT
- صلاحيات RBAC تُطبق من الخادم
- سجل تدقيق Audit Trail
- سير اعتماد Approvals
- الحوكمة
- سجل المخاطر + KRI
- الالتزام + الأدلة والفجوات
- BCM + BIA/MTPD/RTO/RPO
- مؤشرات KPI
- الدعم الإداري والمالي
- مركز الوثائق

## تشغيل سريع بدون Docker

### 1) تشغيل Backend
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload
```

يفتح API على:
`http://127.0.0.1:8000`

توثيق Swagger:
`http://127.0.0.1:8000/docs`

### 2) تشغيل Frontend
من مجلد `frontend`:
```bash
python -m http.server 8080
```

ثم افتح:
`http://127.0.0.1:8080`

## تشغيل Docker Compose
من مجلد المشروع:
```bash
docker compose up --build
```

بعدها:
- الواجهة: `http://localhost:8080`
- API: `http://localhost:8000`
- Swagger: `http://localhost:8000/docs`

## حسابات تجريبية

- admin / Admin@12345
- executive / Executive@12345
- governance / Governance@12345
- risk / Risk@12345
- compliance / Compliance@12345
- bcm / BCM@12345
- finance / Finance@12345
- viewer / Viewer@12345

> هذه بيانات تجريبية فقط ويجب تغييرها قبل أي استخدام فعلي.

## ضوابط قبل الاستخدام الرسمي

1. تغيير SECRET_KEY وجميع كلمات المرور.
2. استخدام PostgreSQL أو SQL Server في البيئة المؤسسية.
3. ربط SSO / Active Directory / Entra ID.
4. تعطيل الحسابات التجريبية.
5. إضافة MFA حسب سياسة الجهة.
6. إضافة تخزين ملفات فعلي للوثائق والمرفقات.
7. فصل بيئات DEV / UAT / PROD.
8. تفعيل HTTPS فقط.
9. تفعيل النسخ الاحتياطي والتعافي من الكوارث.
10. ربط SIEM ومراقبة السجلات الأمنية.
11. تطبيق فصل المهام SoD.
12. عدم السماح لصاحب المخرج باعتماد مخرجه عند تفعيل مسارات الاعتماد النهائية.
