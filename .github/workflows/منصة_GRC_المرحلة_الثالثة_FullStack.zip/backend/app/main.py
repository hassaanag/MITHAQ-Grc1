
from datetime import datetime, timedelta, timezone
from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy import create_engine, String, Integer, Float, Text, DateTime, ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session
from jose import jwt, JWTError
from passlib.context import CryptContext
import os

APP_NAME = "GRC Platform Phase 3"
SECRET_KEY = os.getenv("SECRET_KEY", "CHANGE_ME_IN_PRODUCTION")
ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "480"))
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./grc_phase3.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(200))
    hashed_password: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(50), default="viewer")
    active: Mapped[int] = mapped_column(Integer, default=1)

class Governance(Base):
    __tablename__ = "governance"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(100))
    title: Mapped[str] = mapped_column(String(250))
    owner: Mapped[str] = mapped_column(String(200))
    version: Mapped[str] = mapped_column(String(50), default="1.0")
    approval_authority: Mapped[str] = mapped_column(String(200), default="")
    review_date: Mapped[str] = mapped_column(String(30), default="")
    status: Mapped[str] = mapped_column(String(50), default="مسودة")

class Risk(Base):
    __tablename__ = "risks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(300))
    category: Mapped[str] = mapped_column(String(100))
    owner: Mapped[str] = mapped_column(String(200))
    probability: Mapped[int] = mapped_column(Integer, default=1)
    impact: Mapped[int] = mapped_column(Integer, default=1)
    kri: Mapped[str] = mapped_column(Text, default="")
    treatment: Mapped[str] = mapped_column(Text, default="")
    due_date: Mapped[str] = mapped_column(String(30), default="")
    status: Mapped[str] = mapped_column(String(50), default="مفتوح")

class Compliance(Base):
    __tablename__ = "compliance"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requirement: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(250))
    owner: Mapped[str] = mapped_column(String(200))
    control: Mapped[str] = mapped_column(Text, default="")
    compliance_pct: Mapped[float] = mapped_column(Float, default=0)
    evidence: Mapped[str] = mapped_column(Text, default="")
    gap: Mapped[str] = mapped_column(Text, default="")
    corrective_action: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(50), default="متابعة")

class BCMService(Base):
    __tablename__ = "bcm_services"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    service_name: Mapped[str] = mapped_column(String(250))
    owner: Mapped[str] = mapped_column(String(200))
    mtpd: Mapped[str] = mapped_column(String(50))
    rto: Mapped[str] = mapped_column(String(50))
    rpo: Mapped[str] = mapped_column(String(50))
    dependencies: Mapped[str] = mapped_column(Text, default="")
    recovery_strategy: Mapped[str] = mapped_column(Text, default="")
    last_test: Mapped[str] = mapped_column(String(30), default="")
    readiness_pct: Mapped[float] = mapped_column(Float, default=0)

class KPI(Base):
    __tablename__ = "kpis"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(250))
    owner: Mapped[str] = mapped_column(String(200))
    target: Mapped[float] = mapped_column(Float, default=0)
    actual: Mapped[float] = mapped_column(Float, default=0)
    unit: Mapped[str] = mapped_column(String(30), default="%")

class AdminRequest(Base):
    __tablename__ = "admin_requests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    request_no: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    request_type: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text)
    amount: Mapped[float] = mapped_column(Float, default=0)
    owner: Mapped[str] = mapped_column(String(200))
    approval_stage: Mapped[str] = mapped_column(String(100), default="")
    status: Mapped[str] = mapped_column(String(50), default="تحت الإجراء")
    due_date: Mapped[str] = mapped_column(String(30), default="")

class DocumentRecord(Base):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(250))
    category: Mapped[str] = mapped_column(String(100))
    linked_reference: Mapped[str] = mapped_column(String(200), default="")
    owner: Mapped[str] = mapped_column(String(200))
    version: Mapped[str] = mapped_column(String(50), default="1.0")
    status: Mapped[str] = mapped_column(String(50), default="مسودة")

class Approval(Base):
    __tablename__ = "approvals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(300))
    module: Mapped[str] = mapped_column(String(100))
    requester: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(50), default="معلق")
    decision_by: Mapped[str] = mapped_column(String(200), default="")
    decision_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    username: Mapped[str] = mapped_column(String(100))
    role: Mapped[str] = mapped_column(String(50))
    action: Mapped[str] = mapped_column(String(100))
    module: Mapped[str] = mapped_column(String(100))
    details: Mapped[str] = mapped_column(Text, default="")

Base.metadata.create_all(bind=engine)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token")

class Token(BaseModel):
    access_token: str
    token_type: str

class UserOut(BaseModel):
    username: str
    full_name: str
    role: str

class GovIn(BaseModel):
    type: str
    title: str
    owner: str
    version: str = "1.0"
    approval_authority: str = ""
    review_date: str = ""
    status: str = "مسودة"

class RiskIn(BaseModel):
    code: str
    title: str
    category: str
    owner: str
    probability: int = 1
    impact: int = 1
    kri: str = ""
    treatment: str = ""
    due_date: str = ""
    status: str = "مفتوح"

class ComplianceIn(BaseModel):
    requirement: str
    source: str
    owner: str
    control: str = ""
    compliance_pct: float = 0
    evidence: str = ""
    gap: str = ""
    corrective_action: str = ""
    status: str = "متابعة"

class BCMIn(BaseModel):
    service_name: str
    owner: str
    mtpd: str
    rto: str
    rpo: str
    dependencies: str = ""
    recovery_strategy: str = ""
    last_test: str = ""
    readiness_pct: float = 0

class KPIIn(BaseModel):
    name: str
    owner: str
    target: float
    actual: float
    unit: str = "%"

class AdminIn(BaseModel):
    request_no: str
    request_type: str
    description: str
    amount: float = 0
    owner: str
    approval_stage: str = ""
    status: str = "تحت الإجراء"
    due_date: str = ""

class DocumentIn(BaseModel):
    name: str
    category: str
    linked_reference: str = ""
    owner: str
    version: str = "1.0"
    status: str = "مسودة"

class ApprovalIn(BaseModel):
    title: str
    module: str
    requester: str

ROLE_PERMISSIONS = {
    "admin": {"manage", "approve", "audit"},
    "executive": {"approve", "audit"},
    "governance": {"manage_governance"},
    "risk": {"manage_risk"},
    "compliance": {"manage_compliance"},
    "bcm": {"manage_bcm"},
    "finance": {"manage_admin"},
    "viewer": set(),
}

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_access_token(data: dict):
    exp = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_MINUTES)
    payload = data.copy()
    payload.update({"exp": exp})
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def get_user(db: Session, username: str):
    return db.query(User).filter(User.username == username).first()

def authenticate_user(db: Session, username: str, password: str):
    user = get_user(db, username)
    if not user or not pwd_context.verify(password, user.hashed_password) or not user.active:
        return None
    return user

def current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    exc = HTTPException(status_code=401, detail="بيانات الدخول غير صالحة")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise exc
    except JWTError:
        raise exc
    user = get_user(db, username)
    if not user:
        raise exc
    return user

def require_permission(*permissions):
    def checker(user: User = Depends(current_user)):
        perms = ROLE_PERMISSIONS.get(user.role, set())
        if "manage" in perms:
            return user
        if not any(p in perms for p in permissions):
            raise HTTPException(status_code=403, detail="لا توجد صلاحية كافية")
        return user
    return checker

def audit(db: Session, user: User, action: str, module: str, details: str = ""):
    row = AuditLog(username=user.username, role=user.role, action=action, module=module, details=details)
    db.add(row)
    db.commit()

def seed_data():
    db = SessionLocal()
    try:
        if not db.query(User).first():
            users = [
                ("admin", "مدير النظام", "Admin@12345", "admin"),
                ("executive", "الراعي التنفيذي", "Executive@12345", "executive"),
                ("risk", "مدير المخاطر", "Risk@12345", "risk"),
                ("governance", "مدير الحوكمة", "Governance@12345", "governance"),
                ("compliance", "مدير الالتزام", "Compliance@12345", "compliance"),
                ("bcm", "مدير استمرارية الأعمال", "BCM@12345", "bcm"),
                ("finance", "الدعم الإداري والمالي", "Finance@12345", "finance"),
                ("viewer", "مستخدم عرض", "Viewer@12345", "viewer"),
            ]
            for username, full_name, password, role in users:
                db.add(User(username=username, full_name=full_name, hashed_password=pwd_context.hash(password), role=role))
        if not db.query(Risk).first():
            db.add_all([
                Risk(code="R-001", title="تأخر اعتماد المخرجات الحرجة", category="تشغيلي", owner="إدارة GRC", probability=4, impact=5, kri="تجاوز 10 أيام", treatment="تفعيل مسار التصعيد", due_date="2026-09-30"),
                Risk(code="R-002", title="ضعف جودة بيانات المخاطر", category="بيانات", owner="ملاك المخاطر", probability=4, impact=4, kri="سجلات ناقصة > 10%", treatment="مراجعة جودة شهرية", due_date="2026-10-15"),
            ])
        if not db.query(Governance).first():
            db.add(Governance(type="إطار", title="إطار الحوكمة المؤسسية", owner="إدارة الحوكمة", version="2.0", approval_authority="الراعي التنفيذي", review_date="2026-12-20", status="قيد المراجعة"))
        if not db.query(Compliance).first():
            db.add(Compliance(requirement="توثيق الأدلة الرقابية", source="سجل الالتزام", owner="الإدارات المالكة", control="ربط كل متطلب بدليل", compliance_pct=74, evidence="37/50", gap="أدلة ناقصة", corrective_action="استكمال الأدلة", status="متابعة"))
        if not db.query(BCMService).first():
            db.add(BCMService(service_name="مركز القيادة والسيطرة", owner="العمليات", mtpd="4 ساعات", rto="2 ساعة", rpo="15 دقيقة", dependencies="اتصالات وأنظمة تشغيلية", recovery_strategy="موقع بديل", last_test="2026-07-20", readiness_pct=92))
        if not db.query(KPI).first():
            db.add_all([
                KPI(name="نسبة المخرجات المعتمدة", owner="الحوكمة", target=95, actual=81, unit="%"),
                KPI(name="جاهزية استمرارية الأعمال", owner="BCM", target=90, actual=82, unit="%"),
            ])
        if not db.query(AdminRequest).first():
            db.add(AdminRequest(request_no="A-1001", request_type="طلب شراء", description="خدمات منصة GRC", amount=48000, owner="الدعم الإداري والمالي", approval_stage="مراجعة مالية", status="تحت الإجراء", due_date="2026-10-01"))
        if not db.query(DocumentRecord).first():
            db.add(DocumentRecord(name="منهجية استمرارية الأعمال", category="BCM", linked_reference="منهجية BCM", owner="استمرارية الأعمال", version="4.0", status="معتمد"))
        if not db.query(Approval).first():
            db.add(Approval(title="اعتماد مصفوفة الصلاحيات المؤسسية", module="الحوكمة", requester="إدارة الحوكمة", status="معلق"))
        db.commit()
    finally:
        db.close()

seed_data()

app = FastAPI(title=APP_NAME, version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"status": "ok", "service": APP_NAME}

@app.post("/api/auth/token", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = authenticate_user(db, form.username, form.password)
    if not user:
        raise HTTPException(status_code=401, detail="اسم المستخدم أو كلمة المرور غير صحيحة")
    token = create_access_token({"sub": user.username, "role": user.role})
    audit(db, user, "تسجيل دخول", "المصادقة", "")
    return {"access_token": token, "token_type": "bearer"}

@app.get("/api/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return {"username": user.username, "full_name": user.full_name, "role": user.role}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db), user: User = Depends(current_user)):
    risks = db.query(Risk).all()
    compliance = db.query(Compliance).all()
    bcm = db.query(BCMService).all()
    kpis = db.query(KPI).all()
    approvals = db.query(Approval).filter(Approval.status == "معلق").count()
    high = sum(1 for r in risks if r.probability * r.impact >= 12)
    comp_avg = round(sum(x.compliance_pct for x in compliance) / max(1, len(compliance)), 1)
    bcm_avg = round(sum(x.readiness_pct for x in bcm) / max(1, len(bcm)), 1)
    kpi_avg = round(sum((x.actual / x.target * 100) if x.target else 0 for x in kpis) / max(1, len(kpis)), 1)
    return {
        "high_risks": high,
        "compliance_avg": comp_avg,
        "bcm_readiness": bcm_avg,
        "kpi_achievement": kpi_avg,
        "pending_approvals": approvals
    }

def crud_list(model):
    def endpoint(db: Session = Depends(get_db), user: User = Depends(current_user)):
        rows = db.query(model).order_by(model.id.desc()).all()
        return [{c.name: getattr(r, c.name) for c in model.__table__.columns} for r in rows]
    return endpoint

@app.get("/api/governance")
def list_governance(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return crud_list(Governance)(db, user)

@app.post("/api/governance")
def add_governance(payload: GovIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_governance"))):
    row = Governance(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "الحوكمة", row.title)
    return {"id": row.id}

@app.get("/api/risks")
def list_risks(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.query(Risk).order_by(Risk.id.desc()).all()
    return [{
        "id": r.id, "code": r.code, "title": r.title, "category": r.category, "owner": r.owner,
        "probability": r.probability, "impact": r.impact, "score": r.probability*r.impact,
        "level": "حرج" if r.probability*r.impact >=20 else "مرتفع" if r.probability*r.impact >=12 else "متوسط" if r.probability*r.impact >=6 else "منخفض",
        "kri": r.kri, "treatment": r.treatment, "due_date": r.due_date, "status": r.status
    } for r in rows]

@app.post("/api/risks")
def add_risk(payload: RiskIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_risk"))):
    row = Risk(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "المخاطر", f"{row.code} - {row.title}")
    return {"id": row.id}

@app.get("/api/compliance")
def list_compliance(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return crud_list(Compliance)(db, user)

@app.post("/api/compliance")
def add_compliance(payload: ComplianceIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_compliance"))):
    row = Compliance(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "الالتزام", row.requirement[:120])
    return {"id": row.id}

@app.get("/api/bcm")
def list_bcm(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return crud_list(BCMService)(db, user)

@app.post("/api/bcm")
def add_bcm(payload: BCMIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_bcm"))):
    row = BCMService(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "استمرارية الأعمال", row.service_name)
    return {"id": row.id}

@app.get("/api/kpis")
def list_kpis(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.query(KPI).order_by(KPI.id.desc()).all()
    return [{"id":x.id,"name":x.name,"owner":x.owner,"target":x.target,"actual":x.actual,"unit":x.unit,
             "achievement_pct": round((x.actual/x.target*100),1) if x.target else 0} for x in rows]

@app.post("/api/kpis")
def add_kpi(payload: KPIIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_governance","manage_risk","manage_compliance","manage_bcm","manage_admin"))):
    row = KPI(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "مؤشرات الأداء", row.name)
    return {"id": row.id}

@app.get("/api/admin-requests")
def list_admin(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return crud_list(AdminRequest)(db, user)

@app.post("/api/admin-requests")
def add_admin(payload: AdminIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_admin"))):
    row = AdminRequest(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "الدعم الإداري والمالي", row.request_no)
    return {"id": row.id}

@app.get("/api/documents")
def list_docs(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return crud_list(DocumentRecord)(db, user)

@app.post("/api/documents")
def add_doc(payload: DocumentIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_governance","manage_risk","manage_compliance","manage_bcm","manage_admin"))):
    row = DocumentRecord(**payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "إضافة", "الوثائق", row.name)
    return {"id": row.id}

@app.get("/api/approvals")
def list_approvals(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return crud_list(Approval)(db, user)

@app.post("/api/approvals")
def add_approval(payload: ApprovalIn, db: Session = Depends(get_db), user: User = Depends(require_permission("manage_governance","manage_risk","manage_compliance","manage_bcm","manage_admin"))):
    row = Approval(**payload.model_dump(), status="معلق")
    db.add(row); db.commit(); db.refresh(row)
    audit(db, user, "طلب اعتماد", "الاعتمادات", row.title)
    return {"id": row.id}

@app.post("/api/approvals/{approval_id}/decision")
def approval_decision(approval_id: int, decision: str, db: Session = Depends(get_db), user: User = Depends(require_permission("approve"))):
    if decision not in ["معتمد","مرفوض"]:
        raise HTTPException(status_code=400, detail="قرار غير صالح")
    row = db.query(Approval).filter(Approval.id == approval_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="طلب الاعتماد غير موجود")
    row.status = decision
    row.decision_by = user.full_name
    row.decision_at = datetime.now(timezone.utc)
    db.commit()
    audit(db, user, "قرار اعتماد", "الاعتمادات", f"{row.title}: {decision}")
    return {"status": decision}

@app.get("/api/audit")
def list_audit(db: Session = Depends(get_db), user: User = Depends(require_permission("audit"))):
    rows = db.query(AuditLog).order_by(AuditLog.id.desc()).limit(500).all()
    return [{
        "id":x.id, "created_at":x.created_at.isoformat(), "username":x.username,
        "role":x.role, "action":x.action, "module":x.module, "details":x.details
    } for x in rows]
