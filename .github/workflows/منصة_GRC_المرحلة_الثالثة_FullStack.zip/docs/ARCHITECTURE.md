# معمارية المرحلة الثالثة

## 1. طبقة العرض
Frontend عربي RTL يعمل كعميل API.

## 2. طبقة API
FastAPI:
- Auth
- RBAC
- Governance
- Risks
- Compliance
- BCM
- KPI
- Administrative & Financial Support
- Documents
- Approvals
- Audit

## 3. طبقة البيانات
- SQLite للتطوير المحلي
- PostgreSQL في Docker
- SQL Server ممكن عبر تغيير Driver/Connection String

## 4. الأمن
- JWT Access Tokens
- Password Hashing
- Server-side authorization
- CORS
- Audit Trail

## 5. المرحلة المؤسسية اللاحقة
- SSO / AD
- MFA
- Object Storage للمرفقات
- Digital Approval
- Email/SMS/Teams Notifications
- BI Integration
- API Gateway
- SIEM
- Backup/DR
