
const API = localStorage.getItem("grc_api") || "http://127.0.0.1:8000/api";
let token = localStorage.getItem("grc_token") || "";
let me = null;
let cache = {};

const navItems = [
 ["dashboard","لوحة القيادة","مؤشرات تنفيذية موحدة"],
 ["governance","الحوكمة","السياسات والصلاحيات واللجان"],
 ["risks","المخاطر","السجل المؤسسي والمعالجات"],
 ["compliance","الالتزام","المتطلبات والضوابط والأدلة"],
 ["bcm","استمرارية الأعمال","BIA والخطط والتعافي"],
 ["kpis","مؤشرات الأداء","المستهدف والفعلي"],
 ["admin","الإداري والمالي","الطلبات والموافقات"],
 ["documents","الوثائق","المستودع المؤسسي"],
 ["approvals","الاعتمادات","سير العمل والقرار"],
 ["audit","سجل التدقيق","Audit Trail"]
];

const forms = {
 governance:{title:"إضافة سجل حوكمة", endpoint:"/governance", fields:[
  ["type","النوع","select","سياسة|إطار|لجنة|مصفوفة صلاحيات|إجراء"],
  ["title","العنوان","text"],["owner","المالك","text"],["version","الإصدار","text"],
  ["approval_authority","جهة الاعتماد","text"],["review_date","المراجعة القادمة","date"],
  ["status","الحالة","select","مسودة|قيد المراجعة|قيد الاعتماد|معتمد|فعال"]
 ]},
 risks:{title:"إضافة خطر", endpoint:"/risks", fields:[
  ["code","رمز الخطر","text"],["title","وصف الخطر","textarea"],["category","الفئة","text"],["owner","المالك","text"],
  ["probability","الاحتمالية 1-5","number"],["impact","الأثر 1-5","number"],["kri","KRI","text"],
  ["treatment","المعالجة","textarea"],["due_date","الاستحقاق","date"],["status","الحالة","select","مفتوح|قيد المعالجة|مغلق"]
 ]},
 compliance:{title:"إضافة متطلب التزام", endpoint:"/compliance", fields:[
  ["requirement","المتطلب","textarea"],["source","المصدر","text"],["owner","الإدارة المالكة","text"],["control","الضابط","textarea"],
  ["compliance_pct","نسبة الالتزام","number"],["evidence","الأدلة","text"],["gap","الفجوة","textarea"],["corrective_action","الإجراء التصحيحي","textarea"],
  ["status","الحالة","select","متابعة|قيد المعالجة|مكتمل|متأخر"]
 ]},
 bcm:{title:"إضافة خدمة حرجة", endpoint:"/bcm", fields:[
  ["service_name","الخدمة","text"],["owner","المالك","text"],["mtpd","MTPD","text"],["rto","RTO","text"],["rpo","RPO","text"],
  ["dependencies","الاعتماديات","textarea"],["recovery_strategy","استراتيجية التعافي","textarea"],["last_test","آخر اختبار","date"],["readiness_pct","الجاهزية %","number"]
 ]},
 kpis:{title:"إضافة مؤشر أداء", endpoint:"/kpis", fields:[
  ["name","اسم المؤشر","text"],["owner","المالك","text"],["target","المستهدف","number"],["actual","الفعلي","number"],["unit","الوحدة","select","%|عدد|يوم|ساعة"]
 ]},
 admin:{title:"إضافة طلب إداري/مالي", endpoint:"/admin-requests", fields:[
  ["request_no","رقم الطلب","text"],["request_type","النوع","select","طلب شراء|مستخلص مالي|أمر تكليف|طلب موارد|صيانة|خدمة مساندة"],
  ["description","الوصف","textarea"],["amount","القيمة","number"],["owner","المالك","text"],["approval_stage","مرحلة الاعتماد","text"],
  ["status","الحالة","select","تحت الإجراء|مراجعة|معتمد|متأخر|مكتمل"],["due_date","الاستحقاق","date"]
 ]},
 documents:{title:"إضافة وثيقة", endpoint:"/documents", fields:[
  ["name","اسم الوثيقة","text"],["category","التصنيف","select","حوكمة|مخاطر|التزام|BCM|KPI|إداري ومالي"],
  ["linked_reference","المرجع المرتبط","text"],["owner","المالك","text"],["version","الإصدار","text"],
  ["status","الحالة","select","مسودة|قيد المراجعة|معتمد|فعال"]
 ]},
 approvals:{title:"طلب اعتماد", endpoint:"/approvals", fields:[
  ["title","عنوان الطلب","text"],["module","الوحدة","select","الحوكمة|المخاطر|الالتزام|استمرارية الأعمال|الإداري والمالي"],["requester","مقدم الطلب","text"]
 ]}
};

function qs(id){return document.getElementById(id)}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
function money(v){return Number(v||0).toLocaleString("ar-SA")+" ر.س"}
function lvlClass(level){return ["حرج","مرتفع"].includes(level)?"high":level==="متوسط"?"med":"low"}

async function request(path, options={}){
  options.headers = {...(options.headers||{}), ...(token?{"Authorization":"Bearer "+token}:{})};
  const res = await fetch(API+path, options);
  if(res.status===401){ logout(); throw new Error("انتهت الجلسة"); }
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.detail || "حدث خطأ");
  return data;
}

qs("loginForm").addEventListener("submit", async e=>{
  e.preventDefault();
  qs("loginError").textContent="";
  try{
    const body=new URLSearchParams();
    body.append("username",qs("username").value);
    body.append("password",qs("password").value);
    const res=await fetch(API+"/auth/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
    const data=await res.json();
    if(!res.ok) throw new Error(data.detail||"فشل تسجيل الدخول");
    token=data.access_token; localStorage.setItem("grc_token",token);
    await bootstrap();
  }catch(err){qs("loginError").textContent=err.message}
});

async function bootstrap(){
  if(!token) return;
  try{
    me=await request("/me");
    qs("loginView").classList.add("hidden");
    qs("appView").classList.remove("hidden");
    qs("userName").textContent=me.full_name;
    qs("userRole").textContent=me.role;
    buildNav();
    await loadAll();
  }catch(e){logout()}
}

function buildNav(){
  qs("nav").innerHTML=navItems.map((x,i)=>`<button class="${i===0?"active":""}" data-page="${x[0]}" onclick="showPage('${x[0]}')">${x[1]}</button>`).join("");
  if(!["admin","executive"].includes(me.role)){
    const auditBtn=document.querySelector('button[data-page="audit"]');
    if(auditBtn) auditBtn.style.display="none";
  }
}
function showPage(id){
  document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
  qs(id+"Page").classList.add("active");
  document.querySelectorAll("#nav button").forEach(x=>x.classList.toggle("active",x.dataset.page===id));
  const n=navItems.find(x=>x[0]===id); qs("pageTitle").textContent=n[1];qs("pageSubtitle").textContent=n[2];
}
function logout(){token="";me=null;localStorage.removeItem("grc_token");location.reload()}

async function loadAll(){
  const endpoints=["dashboard","risks","governance","compliance","bcm","kpis","admin-requests","documents","approvals"];
  for(const ep of endpoints){ try{cache[ep]=await request("/"+ep)}catch(e){cache[ep]=[]} }
  if(["admin","executive"].includes(me?.role)){ try{cache.audit=await request("/audit")}catch(e){cache.audit=[]} }
  renderAll();
}

function renderAll(){
  const d=cache.dashboard||{};
  qs("dashboardMetrics").innerHTML=[
    ["المخاطر المرتفعة/الحرجة",d.high_risks??0,"ERM"],
    ["متوسط الالتزام",(d.compliance_avg??0)+"%","Compliance"],
    ["جاهزية BCM",(d.bcm_readiness??0)+"%","BCM"],
    ["تحقق KPI",(d.kpi_achievement??0)+"%","Performance"],
    ["اعتمادات معلقة",d.pending_approvals??0,"Workflow"]
  ].map(x=>`<div class="metric"><div class="label">${x[0]}</div><div class="value">${x[1]}</div><small>${x[2]}</small></div>`).join("");

  const risks=cache.risks||[];
  qs("dashRiskRows").innerHTML=[...risks].sort((a,b)=>b.score-a.score).slice(0,5).map(r=>`<tr><td>${esc(r.code)}</td><td>${esc(r.title)}</td><td>${esc(r.owner)}</td><td>${r.score}/25</td><td><span class="level ${lvlClass(r.level)}">${r.level}</span></td></tr>`).join("");
  qs("riskRows").innerHTML=risks.map(r=>`<tr><td>${esc(r.code)}</td><td>${esc(r.title)}</td><td>${esc(r.category)}</td><td>${esc(r.owner)}</td><td>${r.probability}</td><td>${r.impact}</td><td>${r.score}</td><td><span class="level ${lvlClass(r.level)}">${r.level}</span></td><td>${esc(r.kri)}</td><td>${esc(r.treatment)}</td></tr>`).join("");

  const gov=cache.governance||[];
  qs("governanceRows").innerHTML=gov.map(x=>`<tr><td>${esc(x.type)}</td><td>${esc(x.title)}</td><td>${esc(x.owner)}</td><td>${esc(x.version)}</td><td>${esc(x.approval_authority)}</td><td>${esc(x.review_date)}</td><td>${esc(x.status)}</td></tr>`).join("");

  const comp=cache.compliance||[];
  qs("complianceRows").innerHTML=comp.map(x=>`<tr><td>${esc(x.requirement)}</td><td>${esc(x.source)}</td><td>${esc(x.owner)}</td><td>${esc(x.control)}</td><td>${x.compliance_pct}%</td><td>${esc(x.evidence)}</td><td>${esc(x.gap)}</td><td>${esc(x.corrective_action)}</td></tr>`).join("");

  const bcm=cache.bcm||[];
  qs("bcmRows").innerHTML=bcm.map(x=>`<tr><td>${esc(x.service_name)}</td><td>${esc(x.owner)}</td><td>${esc(x.mtpd)}</td><td>${esc(x.rto)}</td><td>${esc(x.rpo)}</td><td>${esc(x.dependencies)}</td><td>${esc(x.recovery_strategy)}</td><td>${x.readiness_pct}%</td></tr>`).join("");

  const kpis=cache.kpis||[];
  qs("kpiCards").innerHTML=kpis.map(x=>`<div class="kpi-card"><div class="kpi-head"><div><b>${esc(x.name)}</b><br><small>${esc(x.owner)}</small></div><span class="pill">${x.actual}${esc(x.unit)} / ${x.target}${esc(x.unit)}</span></div><div class="progress"><span style="width:${Math.min(100,x.achievement_pct)}%"></span></div><small>تحقق ${x.achievement_pct}%</small></div>`).join("");

  const admin=cache["admin-requests"]||[];
  qs("adminRows").innerHTML=admin.map(x=>`<tr><td>${esc(x.request_no)}</td><td>${esc(x.request_type)}</td><td>${esc(x.description)}</td><td>${money(x.amount)}</td><td>${esc(x.owner)}</td><td>${esc(x.approval_stage)}</td><td>${esc(x.status)}</td><td>${esc(x.due_date)}</td></tr>`).join("");

  const docs=cache.documents||[];
  qs("documentRows").innerHTML=docs.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.category)}</td><td>${esc(x.linked_reference)}</td><td>${esc(x.owner)}</td><td>${esc(x.version)}</td><td>${esc(x.status)}</td></tr>`).join("");

  const approvals=cache.approvals||[];
  qs("dashApprovals").innerHTML=approvals.filter(x=>x.status==="معلق").slice(0,4).map(x=>`<div class="stack-item"><b>${esc(x.title)}</b><small>${esc(x.module)} • ${esc(x.requester)}</small></div>`).join("")||"<small>لا توجد اعتمادات معلقة.</small>";
  qs("approvalCards").innerHTML=approvals.map(x=>`<div class="approval"><div><b>${esc(x.title)}</b><p>${esc(x.module)} • مقدم الطلب: ${esc(x.requester)}</p><span class="pill">${esc(x.status)}</span></div><div class="decision">${x.status==="معلق"&&["admin","executive"].includes(me.role)?`<button class="approve" onclick="decide(${x.id},'معتمد')">اعتماد</button><button class="reject" onclick="decide(${x.id},'مرفوض')">رفض</button>`:""}</div></div>`).join("");

  if(cache.audit){
    qs("auditRows").innerHTML=cache.audit.map(x=>`<tr><td>${esc(x.created_at)}</td><td>${esc(x.username)}</td><td>${esc(x.role)}</td><td>${esc(x.action)}</td><td>${esc(x.module)}</td><td>${esc(x.details)}</td></tr>`).join("");
  }
}

async function decide(id,decision){
  try{await request(`/approvals/${id}/decision?decision=${encodeURIComponent(decision)}`,{method:"POST"});await loadAll()}catch(e){alert(e.message)}
}

function openModal(type){
  const f=forms[type];
  qs("modalTitle").textContent=f.title;
  qs("modalForm").innerHTML=`<div class="form-grid">${f.fields.map(fieldHTML).join("")}<div class="form-actions"><button type="button" class="secondary" onclick="closeModal()">إلغاء</button><button class="primary">حفظ</button></div></div>`;
  qs("modal").classList.remove("hidden");
  qs("modalForm").onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target).entries());
    ["probability","impact","compliance_pct","readiness_pct","target","actual","amount"].forEach(k=>{if(k in data)data[k]=Number(data[k])});
    try{
      await request(f.endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
      closeModal();await loadAll();
    }catch(err){alert(err.message)}
  };
}
function fieldHTML(f){
  const [name,label,type,opts]=f;
  let input="";
  if(type==="select") input=`<select name="${name}" required>${opts.split("|").map(v=>`<option>${v}</option>`).join("")}</select>`;
  else if(type==="textarea") input=`<textarea name="${name}" required></textarea>`;
  else input=`<input name="${name}" type="${type}" required>`;
  return `<div class="field ${type==="textarea"?"full":""}"><label>${label}</label>${input}</div>`;
}
function closeModal(){qs("modal").classList.add("hidden")}
bootstrap();
